#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdio_ext.h>
#include <string.h>
#include <strings.h>
#include <ctype.h>
struct Def_Coordenadas
{
    char x, y;
    int Puntos;
};
struct Def_Leaderboards
{
    char Nombre[30];
    int Puntos;
};
typedef struct Def_Leaderboards LEADERBOARD;
typedef struct Def_Coordenadas COOR;
void CtCalamardo();
void CtEscribir_Leaderboard_Jugador1(LEADERBOARD Ganador,LEADERBOARD Ganadores[100], int puntostotales1);
void CtDecision(int *decision);
int CtGuardar_juego(int Ganar1, int Ganar2, int Contador, char Mapita[22][43], int juegostotales, int Juegos1, int Juegos2, int puntostotales1, int puntostotales2, int Elim1, int Elim2);
void CtCargar_Juego(int *Ganar1, int *Ganar2, int *Contador, char Mapita[22][43], int *puntostotales1, int *puntostotales2, int *juegostotales, int *Juegos1, int *Juegos2, int *Elim1, int *Elim2);
void CtHacer_Mapita(char Mapita[22][43]);
void CtImprimir_Mapita(char Mapita[22][43]);
void CtPrimer_Jugada(char Mapita[22][43]);
int CtDesea_Salir();
int CtHacer_Jugada(char Mapita[22][43], int *Contador, COOR *Jugador, int *Salir);
void CtObtener_Puntos(char Mapita[22][43], int *Ganar1, int *Ganar2, int *Elim1, int *Elim2, COOR Jugador, int Contador); //Validar puntajes o condiciones para ganar
int CtRecursivaHor1(char Mapita[22][43], int i, int j,  int *Puntos1, int *ContadorX1, int *ContadorX2 ); //Validar si hay puntos o piezas comidas en horizontal para jugador 1
int CtRecursivaVer1(char Mapita[22][43], int i, int j,  int *Puntos1, int *ContadorX1, int *ContadorX2 ); //Validar si ha puntos o piezas comidas en vertical para jugador 1
int CtRecursivaDiagoH1(char Mapita[22][43], int i, int j, int *Puntos1, int *ContadorX1, int *ContadorX2 );//Validar si hay puntos o piezas comidas en diagonal para jugador 1
int CtRecursivaDiagoV1(char Mapita[22][43], int i, int j, int *Puntos1, int *ContadorX1, int *ContadorX2 );//Validar si hay puntos o piezas comidas en diagonal para jugador 1
int CtValidar_Jugada(char Mapita[22][43], int x, int y, int *Minimo, COOR Jugador);
int CtRecursiva_Enemigo(char Mapita[22][43], int i, int j, int *Puntos2, int *ContadorX1, int *ContadorX2, int Contador);

void PvE_Torneo()
{
    COOR Jugador;
    int continuar=1;
    LEADERBOARD Ganador, Ganadores[100];
    int Contador=0, Ganar1=0, Ganar2=0, Elim1=0, Elim2=0, y=21, x=11, Minimo=0, Salir=0, juegostotales=1, Juegos1=0, Juegos2=0, decision=0, puntostotales1=0, puntostotales2=0, hoja, hoja2;
    int turnostranscurridos=0; //Para que no se borren todos los datos cuando se carga un juego en progreso
    char Mapita[22][43], cont;
    CtHacer_Mapita(Mapita);
    CtDecision(&decision);
    if(decision==3)
    {
        printf("ERROR FATAL: No existe el archivo que deseas abrir\n");
        exit(100);
    }
    if(decision==2)
    {
        CtImprimir_Mapita(Mapita);
        printf("Jugador 1, da dos <enter> para hacer la primer jugada.\n");
        scanf("%c", &cont);
        CtPrimer_Jugada(Mapita);
        Contador++;
        CtImprimir_Mapita(Mapita);
    }
    if(decision==1)
    {
        turnostranscurridos=2;
        CtCargar_Juego(&Ganar1, &Ganar2, &Contador, Mapita, &juegostotales, &Juegos1, &Juegos2, &puntostotales1, &puntostotales2, &Elim1, &Elim2);
        __fpurge(stdin);
        hoja=puntostotales1;
        puntostotales1=juegostotales;
        hoja2=puntostotales2;
        juegostotales= hoja2;
        puntostotales2=hoja;
        juegostotales= hoja2;
        juegostotales= Juegos2;
        Juegos2=hoja2;
        hoja=Juegos1;
        Juegos1=puntostotales2;
        puntostotales2=hoja;
        getchar();
        CtImprimir_Mapita(Mapita);
	printf("%d, %d, %d, %d, %d\n", Elim1, Elim2, Ganar1, Ganar2, Contador);
        printf("Presiona enter para continuar\n");
        scanf("%c", &cont);
        __fpurge(stdin);
    }
    do
    {
        if(juegostotales>0 && turnostranscurridos==0)
        {
            Contador=0;
            CtHacer_Mapita(Mapita);
            CtImprimir_Mapita(Mapita);
            printf("Jugador 1, da un <enter> para hacer la primer jugada.\n");
            scanf("%c", &cont);
            __fpurge(stdin);
            CtPrimer_Jugada(Mapita);
            Contador++;
            CtImprimir_Mapita(Mapita);
            Ganar1=0;
            Ganar2=0;
	    Elim1=0;
	    Elim2=0;
        }
        do
        {
            Salir=0;
            Minimo=0;
            printf("Numero de juego: %d. Juegos jugador 1: %d. Jugador 2: %d. Puntos jug 1: %d, Puntos jug 2: %d\n", juegostotales, Juegos1, Juegos2, puntostotales1, puntostotales2);
            CtHacer_Jugada(Mapita, &Contador, &Jugador, &Salir);
            if(Salir==-99)
            {
                if(Contador%2==0 && Mapita[Jugador.y][Jugador.x]=='O')
                {
                    Mapita[Jugador.y][Jugador.x]='O';
                }
                if(Contador%2!=0 && Mapita[Jugador.y][Jugador.x]=='O')
                {
                    Mapita[Jugador.y][Jugador.x]='O';
                }
                if(Contador%2!=0 && Mapita[Jugador.y][Jugador.x]=='X')
                {
                    Mapita[Jugador.y][Jugador.x]='X';
                }
                if(Contador%2==0 && Mapita[Jugador.y][Jugador.x]=='X')
                {
                    Mapita[Jugador.y][Jugador.x]='X';
                }
            }
            if(Salir==1)
            {
                if(CtDesea_Salir()==1)
                {
		  if(Ganar2<0)
		    {
		      Ganar2=0;
		    }
		  if(Ganar1<0)
		    {
		      Ganar1=0;
		    }
		  CtGuardar_juego(Ganar1, Ganar2, Contador,  Mapita, juegostotales, Juegos1, Juegos2, puntostotales1, puntostotales2, Elim1, Elim2);
                    exit(100);
                }
                else
                {
                    exit(100);
                }
            }
            if(Contador==3)
            {
                Mapita[11][21]='X';
                if(CtValidar_Jugada(Mapita, x, y, &Minimo, Jugador)>500)
                {
                    printf("ERROR: Primer jugada invalida, las reglas del juego se encuentran al inicio del programa\n");
                    Minimo=0;
                    Contador=Contador-1;
                    Mapita[x][y]='+';
                    printf("Presiona <enter> para volver a intentar ");
                    getchar();
                    __fpurge(stdin);
                    Salir=-90;
                }
                Mapita[11][21]='O';
            }
            if(Salir==0)
            {
                CtObtener_Puntos(Mapita, &Ganar1, &Ganar2, &Elim1, &Elim2, Jugador, Contador);
                Salir=0;
            }
            CtImprimir_Mapita(Mapita);
            turnostranscurridos=0;
        }
        while(Ganar1<50&Ganar2<50&&Elim1<50&&Elim2<50);
        if(Ganar1>=50||Elim1>=50)
        {
	  if(Elim1>=50)
	    {
	      Ganar1=Ganar1+100;
	    }
	  Ganar1=Ganar1+Elim1;
	  printf("Ganó el JUGADOR 1, puntos %d\n\n", Ganar1);
	  printf("Presiona enter para continuar... ");
	  getchar();
	  Juegos1=Juegos1+1;
        }
        if(Ganar2>=50||Elim2>=50)
        {
	  if(Elim2>=50)
	    {
	      Ganar2=Ganar2+100;
	    }
	  Ganar2=Ganar2+Elim2;
	  printf("Ganó el JUGADOR 2, puntos %d\n\n", Ganar2);
	  printf("Presiona enter para continuar... ");
	  getchar();
	  Juegos2=Juegos2+1;
        }
	if(Ganar2<0)
	  {
	    Ganar2=0;
	  }
	if(Ganar1<0)
	  {
	    Ganar1=0;
	  }
        juegostotales=juegostotales+1;
        puntostotales1= puntostotales1+ Ganar1;
        puntostotales2=puntostotales2+ Ganar2;
        turnostranscurridos=0;
    }
    while(juegostotales<=5);
    if(Juegos1>Juegos2)
    {
        printf("Gano el jugador 1 con %d juegos y %d puntos\n", Juegos1, puntostotales1);
        CtEscribir_Leaderboard_Jugador1(Ganador,Ganadores, puntostotales1);
        exit(100);
    }
    else
    {
      CtCalamardo();
        exit(100);
    }
    if(Juegos1==Juegos2)
    {
        printf("Empate\n");
        exit(100);
    }
}

void CtDecision(int *decision)
{
    FILE *Archivo;
    float dec;
    do
    {
        printf("Bienvenido a Pente, deseas cargar un juego de este modo o iniciar uno nuevo? Presiona 1 para cargar, 2 para juego nuevo: ");
        scanf("%f", &dec);
        __fpurge(stdin);
        if(!(dec-1==0 ||  dec-2==0))
        {
            __fpurge(stdin);
            printf("ERROR: Dame valores validos\n");
        }
    }
    while(!(dec-1==0||dec-2==0));
    __fpurge(stdin);
    *decision= dec;
    if(*decision==1)
    {
        if((Archivo=fopen("torneo.bin","rb"))==NULL)
        {
            *decision=3;
        }
        else
        {
        }
    }
    __fpurge(stdin);
}
void CtCargar_Juego(int *Ganar1, int *Ganar2, int *Contador, char Mapita[22][43], int *puntostotales1, int *puntostotales2, int *juegostotales, int *Juegos1, int *Juegos2, int *Elim1, int *Elim2)
{
    FILE *Archivo;
    int i, j;
    __fpurge(stdin);
    Archivo=fopen("torneo.bin", "rb");
    fread(puntostotales1, sizeof(int), 1, Archivo);
    fread(puntostotales2, sizeof(int), 1, Archivo);
    fread(juegostotales, sizeof(int), 1, Archivo);
    fread(Juegos1, sizeof(int), 1, Archivo);
    fread(Juegos2, sizeof(int), 1, Archivo);
    fread(Ganar1, sizeof(int), 1, Archivo);
    fread(Ganar2, sizeof(int), 1, Archivo);
    fread(Elim1, sizeof(int), 1, Archivo);
    fread(Elim1, sizeof(int), 1, Archivo);
    fread(Contador, sizeof(int), 1, Archivo);
    for(i=0; i<22; i++)
    {
        for(j=0; j<43; j++)
        {
            fread(&Mapita[i][j], sizeof(char), 1, Archivo);
        }
    }
    fclose(Archivo);
}
void CtHacer_Mapita(char Mapita[22][43])
{
    int i, j;
    char letra='a';
    for(i=0; i<22; i++)
    {
        for(j=0; j<43; j++)
        {
            Mapita[i][j]=' ';
        }
    }
    for(i=1; i<22; i++)
    {
        for(j=2; j<42; j++)
        {
            Mapita[i][j]=' ';
            j++;
            Mapita[i][j]='+';
        }
    }
    
    for(i=1; i<22; i++)
    {
        for(j=2; j<42; j++)
        {
            if((i==1)||(i==21))
            {
                Mapita[i][j]='-';
                j++;
                Mapita[i][j]='-';
            }
            if(j==2||j==41)
            {
                Mapita[i][j]='|';
            }
        }
    }
    for(j=0, i=2; i<21; i++, letra++)
    {
        Mapita[i][j]=letra;
        Mapita[i][j+1]=' ';
    }
    letra='a';
    for(j=3, i=0; j<41; j++, letra++)
    {
        Mapita[i][j]=letra;
        j++;
        Mapita[i][j]=' ';
    }
    Mapita[0][0]=' ';
    Mapita[0][1]=' ';
    Mapita[1][0]=' ';
    Mapita[1][1]=' ';
}
void CtImprimir_Mapita(char Mapita[22][43])
{
    int i, j;
    system("clear");
    printf("\n\n\n\t\t\t\t\t   Pente\n\n");
    for(i=0; i<22; i++)
    {
        for(j=0; j<43; j++)
        {
            if(j==0)
            {
                printf("\t\t\t");
            }
            printf("%c", Mapita[i][j]);
        }
        printf("\n");
    }
    printf("\n");
}
void CtPrimer_Jugada(char Mapita[22][43])
{
    int i, j;
    i=(21/2)+1;
    j=(41/2)+2;
    Mapita[i][j-1]='O';
}

int CtHacer_Jugada(char Mapita[22][43], int *Contador, COOR *Jugador, int *Salir)
{
    char x, y;
    int i=76;
    *Salir=0;
    if(*Contador%2==0)
    {
        printf("Coordenadas para jugador (x, y), ingresa 0 si deseas salir del juego: ");
        while(!((scanf("%c, %c",&x,&y)==2) &&((x>='a' && x<='s') ||     (x>='A' && x<='S')) &&((y>='a' && y<='s')||(y>='A' &&   y<='S'))||(x=='0')))
        {
            __fpurge(stdin);
            printf("No me des valores invalidos, intenta otra vez\n");
            printf("Dame tu coordenadas (x,y)  ");
        }
        if(x=='0')
        {
            *Salir=1;
            return 1;
        }
        __fpurge(stdin);
        x= tolower(x);
        y= tolower(y);
        (*Jugador).x=x;
        (*Jugador).y=y;
        Jugador->y=Jugador->y-95;
        if(Jugador->x!='s')
        {
            i=i+('s'-Jugador->x);
        }
        Jugador->x=Jugador->x-i;
        if(*Contador%2==0 && Mapita[Jugador->y][Jugador->x]=='X')
        {
            printf("Usted no puede hacer su jugada por encima de otra ficha.\nPresiona <enter> para volver a intentarlo: ");
            __fpurge(stdin);
            getchar();
            *Salir=-90;
            return 0;
        }
        if(*Contador%2!=0 && Mapita[Jugador->y][Jugador->x]=='O')
        {
            printf("Usted no puede hacer su jugada por encima de otra       ficha.\nPresiona <enter> para volver a intentarlo: ");
            __fpurge(stdin);
            getchar();
            *Salir=-90;
            return 0;
        }
        *Salir=0;
        if(*Contador%2!=0)
        Mapita[Jugador->y][Jugador->x]='O';
        *Contador=*Contador+1;
        }
    else
    {
        *Contador=*Contador+1;
    }
}
void CtObtener_Puntos(char Mapita[22][43], int *Ganar1, int *Ganar2, int *Elim1, int *Elim2, COOR Jugador, int Contador)
{
    int Puntos2=1, Puntos1=1, i=Jugador.y, j=Jugador.x, Total2=0, Total1=0, ContadorX1=0, ContadorX2=0;
    if(Contador%2==0)
    {
        if(Contador==2)
        {
            Mapita[12][21]='X';
        }
        if (Contador==4)
        {
            Mapita[12][23]='X';
        }
        if(Contador>4)
        {
            CtRecursiva_Enemigo(Mapita, i, j, &Puntos2, &ContadorX1, &ContadorX2, Contador);
        }
        if(Puntos2>=5&&Contador%2==0)
        {
            Total2=Total2+100;
        }
        if(Puntos2==4&&Contador%2==0)
        {
            Total2=Total2+15;
        }
        Puntos2=1;
        Puntos1=1;
        if(ContadorX2!=0)
        {
            *Elim2=*Elim2+10;
        }
        *Ganar2=*Ganar2+Total2;
        ContadorX2=0;
    }
    else
    {
        Mapita[i][j]='P';
         CtRecursivaHor1(Mapita, i, j, &Puntos1, &ContadorX1, &ContadorX2 );
        if(Puntos1==4)
        {
            Total1=Total1+15;
        }
        if(Puntos1>=5)
        {
            Total1=Total1+100;
        }
        if(ContadorX1!=0)
        {
            *Elim1=*Elim1+10;
        }
        Puntos2=1;
        Puntos1=1;
        ContadorX1=0;
         CtRecursivaVer1(Mapita, i, j, &Puntos1, &ContadorX1, &ContadorX2);
        if(Puntos1==4)
        {
            Total1=Total1+10;
        }
        if(Puntos1>=5)
        {
            Total1=Total1+100;
        }
        if(ContadorX1!=0)
        {
            *Elim1=*Elim1+10;
        }
        Puntos2=1;
        Puntos1=1;
        ContadorX1=0;
         CtRecursivaDiagoH1(Mapita, i, j, &Puntos1, &ContadorX1, &ContadorX2 );
        if(Puntos1>=5)
        {
            Total1=Total1+100;
        }
        if(Puntos1==4)
        {
            Total1=Total1+10;
        }
        if(ContadorX1!=0)
        {
            *Elim1=*Elim1+10;
        }
        Puntos2=1;
        Puntos1=1;
        ContadorX1=0;
         CtRecursivaDiagoV1(Mapita, i, j, &Puntos1, &ContadorX1, &ContadorX2 );
        if(Puntos1>=5)
        {
            Total1=Total1+100;
        }
        if(Puntos1==4)
        {
            Total1=Total1+10;
        }
        if(ContadorX1!=0)
        {
            *Elim1=*Elim1+10;
        }
        Puntos2=1;
        Puntos1=1;
	ContadorX1=0;
	*Ganar1=*Ganar1+Total1;
        if(Contador%2!=0)
        {
            Mapita[i][j]='O';
        }
        else
        {
            Mapita[i][j]='X';
        }
    }
}

int CtRecursivaHor1(char Mapita[22][43], int i, int j,  int *Puntos1, int *ContadorX1, int *ContadorX2 )
{
    if(Mapita[i][j+2]=='X'&&Mapita[i][j+4]=='X'&&Mapita[i][j+6]=='O'&&Mapita[i][j]=='P')
    {
        Mapita[i][j+2]='+';
        Mapita[i][j+4]='+';
        *ContadorX1=*ContadorX1+1;
        
    }
    if(Mapita[i][j-2]=='X'&&Mapita[i][j-4]=='X'&&Mapita[i][j-6]=='O'&&Mapita[i][j]=='P')
    {
        Mapita[i][j-2]='+';
        Mapita[i][j-4]='+';
        *ContadorX1=*ContadorX1+1;
        
    }
    if(Mapita[i][j+2]=='O')
    {
        *Puntos1=*Puntos1+1;
        Mapita[i][j+2]='+';
        CtRecursivaHor1(Mapita, i, j+2, Puntos1, ContadorX1, ContadorX2 );
        Mapita[i][j+2]='O';
    }
    if(Mapita[i][j-2]=='O')
    {
        *Puntos1=*Puntos1+1;
        Mapita[i][j-2]='+';
        CtRecursivaHor1(Mapita, i, j-2, Puntos1, ContadorX1, ContadorX2 );
        Mapita[i][j-2]='O';
    }
    return 0;
}

int CtRecursivaVer1(char Mapita[22][43], int i, int j, int *Puntos1, int *ContadorX1, int *ContadorX2 )
{
    if(Mapita[i+1][j]=='X'&&Mapita[i][j]=='X'&&Mapita[i+3][j]=='O'&&Mapita[i][j]=='P')
    {
        Mapita[i+1][j]='+';
        Mapita[i+2][j]='+';
        *ContadorX1=*ContadorX1+1;
        
    }
    if(Mapita[i-1][j]=='X'&&Mapita[i-2][j]=='X'&&Mapita[i-3][j]=='O'&&Mapita[i][j]=='P')
    {
        Mapita[i-1][j]='+';
        Mapita[i-2][j]='+';
        *ContadorX1=*ContadorX1+1;
        
    }
    if(Mapita[i+1][j]=='O')
    {
        *Puntos1=*Puntos1+1;
        Mapita[i+1][j]='+';
        CtRecursivaVer1(Mapita, i+1, j, Puntos1, ContadorX1, ContadorX2 );
        Mapita[i+1][j]='O';
    }
    if(Mapita[i-1][j]=='O')
    {
        *Puntos1=*Puntos1+1;
        Mapita[i-1][j]='+';
        CtRecursivaVer1(Mapita, i-1, j, Puntos1, ContadorX1, ContadorX2 );
        Mapita[i-1][j]='O';
    }
    return 0;
}

int CtRecursivaDiagoH1(char Mapita[22][43], int i, int j, int *Puntos1, int *ContadorX1, int *ContadorX2 )
{
    if(Mapita[i+1][j+2]=='X'&&Mapita[i+2][j+4]=='X'&&Mapita[i+3][j+6]=='O'&&Mapita[i][j]=='P')
    {
        Mapita[i+1][j+2]='+';
        Mapita[i+2][j+4]='+';
        *ContadorX1=*ContadorX1+1;
        
    }
    if(Mapita[i-1][j-2]=='X'&&Mapita[i-2][j-4]=='X'&&Mapita[i-3][j-6]=='O'&&Mapita[i][j]=='P')
    {
        Mapita[i-1][j-2]='+';
        Mapita[i-2][j-4]='+';
        *ContadorX1=*ContadorX1+1;
        
    }
    if(Mapita[i+1][j+2]=='O')
    {
        *Puntos1=*Puntos1+1;
        Mapita[i+1][j+2]='+';
        CtRecursivaDiagoH1(Mapita, i+1, j+2, Puntos1, ContadorX1, ContadorX2 );
        Mapita[i+1][j+2]='O';
    }
    if(Mapita[i-1][j-2]=='O')
    {
        *Puntos1=*Puntos1+1;
        Mapita[i-1][j-2]='+';
        CtRecursivaDiagoH1(Mapita, i-1, j-2,  Puntos1, ContadorX1, ContadorX2 );
        Mapita[i-1][j-2]='O';
    }
    return 0;
}



int CtRecursivaDiagoV1(char Mapita[22][43], int i, int j, int *Puntos1, int *ContadorX1, int *ContadorX2)
{
    if(Mapita[i+1][j-2]=='X'&&Mapita[i+2][j-4]=='X'&&Mapita[i+3][j-6]=='O'&&Mapita[i][j]=='P')
    {
        Mapita[i+1][j-2]='+';
        Mapita[i+2][j-4]='+';
        *ContadorX1=*ContadorX1+1;
        
    }
    if(Mapita[i-1][j+2]=='X'&&Mapita[i-2][j+4]=='X'&&Mapita[i-3][j+6]=='O'&&Mapita[i][j]=='P')
    {
        Mapita[i-1][j+2]='+';
        Mapita[i-2][j+4]='+';
        *ContadorX1=*ContadorX1+1;
        
    }
    if(Mapita[i+1][j-2]=='O')
    {
        *Puntos1=*Puntos1+1;
        Mapita[i+1][j-2]='+';
        CtRecursivaDiagoV1(Mapita, i+1, j-2, Puntos1, ContadorX1, ContadorX2 );
        Mapita[i+1][j-2]='O';
    }
    if(Mapita[i-1][j+2]=='O')
    {
        *Puntos1=*Puntos1+1;
        Mapita[i-1][j+2]='+';
        CtRecursivaDiagoV1(Mapita, i-1, j+2,  Puntos1, ContadorX1, ContadorX2 );
        Mapita[i-1][j+2]='O';
    }
    return 0;
}

int CtValidar_Jugada(char Mapita[22][43], int x, int y, int *Minimo, COOR Jugador)
{
    if((Mapita[x+1][y]=='O'||Mapita[x-1][y]=='O'||Mapita[x][y+2]=='O'||Mapita[x][y-2]=='O')&&*Minimo<3)
    {
        Mapita[Jugador.y][Jugador.x]='+';
        *Minimo=1000;
        return *Minimo;
    }
    if(Mapita[x+1][y]=='+'&&*Minimo<3) //Camino hacia abajo
    {
        Mapita[x+1][y]='X';
        *Minimo=*Minimo+1;
        CtValidar_Jugada(Mapita, x+1, y, Minimo, Jugador);
        Mapita[x+1][y]='+';
        *Minimo=*Minimo-1;
    }
    if(Mapita[x-1][y]=='+'&&*Minimo<3) //Camino hacia arriba
    {
        Mapita[x-1][y]='X';
        *Minimo=*Minimo+1;
        CtValidar_Jugada(Mapita, x-1, y, Minimo, Jugador);
        Mapita[x-1][y]='+';
        *Minimo=*Minimo-1;
        
    }
    if(Mapita[x][y+2]=='+'&&*Minimo<3) //Camino a la derecha
    {
        Mapita[x][y+2]='X';
        *Minimo=*Minimo+1;
        CtValidar_Jugada(Mapita, x, y+2, Minimo, Jugador);
        Mapita[x][y+2]='+';
        *Minimo=*Minimo-1;
    }
    if(Mapita[x][y-2]=='+'&&*Minimo<3) //Camino a la izquierda
    {
        Mapita[x][y-2]='X';
        *Minimo=*Minimo+1;
        CtValidar_Jugada(Mapita, x, y-2, Minimo, Jugador);
        Mapita[x][y-2]='+';
        *Minimo=*Minimo-1;
    }
    if(Mapita[x-1][y-2]=='+'&&*Minimo<2) //Camino a la izquierda
    {
        Mapita[x-1][y-2]='X';
        *Minimo=*Minimo+1;
        CtValidar_Jugada(Mapita, x-1, y-2, Minimo, Jugador);
        Mapita[x-1][y-2]='+';
        *Minimo=*Minimo-1;
    }
    if(Mapita[x+1][y-2]=='+'&&*Minimo<2) //Camino a la izquierda
    {
        Mapita[x+1][y-2]='X';
        *Minimo=*Minimo+1;
        CtValidar_Jugada(Mapita, x+1, y-2, Minimo, Jugador);
        Mapita[x+1][y-2]='+';
        *Minimo=*Minimo-1;
    }
    if(Mapita[x+1][y+2]=='+'&&*Minimo<3) //Camino a la izquierda
    {
        Mapita[x+1][y+2]='X';
        *Minimo=*Minimo+1;
        CtValidar_Jugada(Mapita, x+1, y+2, Minimo, Jugador);
        Mapita[x+1][y+2]='+';
        *Minimo=*Minimo-1;
    }
    if(Mapita[x-1][y+2]=='+'&&*Minimo<3) //Camino a la izquierda
    {
        Mapita[x-1][y+2]='X';
        *Minimo=*Minimo+1;
        CtValidar_Jugada(Mapita, x-1, y+2, Minimo, Jugador);
        Mapita[x-1][y+2]='+';
        *Minimo=*Minimo-1;
    }
    return *Minimo;
}

int CtDesea_Salir()
{
    float decision;
    int decision2;
    do
    {
        __fpurge(stdin);
        printf("Deseas guardar tu partida o salir sin guardar?, presiona 1 para guardar y 0 para salir: ");
        if(!(((scanf("%f", &decision))==1) &&(decision==0 || decision-1==0)))
        {
            __fpurge(stdin);
            printf("No me des valores invalidos\n");
        }
    }
    while(!(decision==0 || decision-1==0));
    decision2=decision;
    __fpurge(stdin);
    return decision2;
}
int CtGuardar_juego(int Ganar1, int Ganar2, int Contador, char Mapita[22][43], int juegostotales, int Juegos1, int Juegos2, int puntostotales1, int puntostotales2, int Elim1, int Elim2)
{
    FILE *Archivo;
    float decision=0;
    int i, j;
    if((Archivo= fopen("torneo.bin", "rb"))!=NULL)
    {
        do
        {
            printf("ADVERTENCIA: Estas a punto de sobreescribir tu archivo anterior, seguro? 1 para sobreescribir, 2 para cancelar  ");
            if(!(((scanf("%f", &decision))==1) &&(decision==0 || decision-1==0)))
            {
                __fpurge(stdin);
                printf("No me des valores invalidos\n");
            }
        }
        while(!(decision-2==0 || decision-1==0));
        if(decision==2)
        {
            fclose(Archivo);
            return 0;
        }
        fclose(Archivo);
    }
    __fpurge(stdin);
    Archivo=fopen("torneo.bin", "wb");
    fwrite(&puntostotales1, sizeof(int), 1, Archivo);
    fwrite(&puntostotales2, sizeof(int), 1, Archivo);
    fwrite(&juegostotales, sizeof(int), 1, Archivo);
    fwrite(&Juegos1, sizeof(int), 1, Archivo);
    fwrite(&Juegos2, sizeof(int), 1, Archivo);
    fwrite(&Ganar1, sizeof(int), 1, Archivo);
    fwrite(&Ganar2, sizeof(int), 1, Archivo);
    fwrite(&Elim1, sizeof(int), 1, Archivo);
    fwrite(&Elim2, sizeof(int), 1, Archivo);
    fwrite(&Contador, sizeof(int), 1, Archivo);
    for(i=0; i<22; i++)
    {
        for(j=0; j<43; j++)
        {
            fwrite(&Mapita[i][j], sizeof(char), 1, Archivo);
        }
    }
    fclose(Archivo);
}
void CtEscribir_Leaderboard_Jugador1(LEADERBOARD Ganador,LEADERBOARD Ganadores[100], int puntostotales1)
{
    FILE *Archivo;
    int i=0, j, totaljugadores=0;
    LEADERBOARD Hoja;
    printf("Dame el nombre del jugador 1: ");
    fgets(Ganador.Nombre, 30, stdin);
    Ganador.Nombre[strlen(Ganador.Nombre)-1]=0;
    Ganador.Puntos=puntostotales1;
    printf("%s %d\n", Ganador.Nombre, Ganador.Puntos);
    if((Archivo=fopen("leaderboards.txt", "rt"))==NULL)
    {
        Archivo=fopen("leaderboards.txt", "wt");
        fprintf(Archivo, "%s %d\n", Ganador.Nombre, Ganador.Puntos);
        fclose(Archivo);
    }
    else
    {
        while((fscanf(Archivo, "%s %d\n", Ganadores[i].Nombre, &Ganadores[i].Puntos))==2)
        {
            i=i+1;
        }
        i=i+1;
        strcpy(Ganadores[i].Nombre,Ganador.Nombre);
        Ganadores[i].Puntos= Ganador.Puntos;
        totaljugadores= i;
        for(i=0; i<totaljugadores; i++)
        {
            for(j=i+1; j<totaljugadores; j++)
            {
                if(Ganadores[i].Puntos<Ganadores[j].Puntos)
                {
                    Hoja=Ganadores[i];
                    Ganadores[i]=Ganadores[j];
                    Ganadores[j]=Hoja;
                }
            }
        }
        fclose(Archivo);
        Archivo=fopen("leaderboards.txt", "wt");
        for(i=0; i<totaljugadores; i++)
        {
            fprintf(Archivo, "%s %d\n", Ganadores[i].Nombre, Ganadores[i].Puntos);
        }
    }
}
int CtRecursiva_Enemigo(char Mapita[22][43], int i, int j, int *Puntos2, int *ContadorX1, int *ContadorX2, int Contador)
{
    //Acabe Recursiva
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    //Movimiento Horizontal
    if(Mapita[i][j-4]=='O'&&Mapita[i][j-6]=='O'&&Mapita[i][j-8]=='X')
    {
        if(Mapita[i][j-2]=='+')
        {
            Mapita[i][j-2]=='X';
            Mapita[i][j-4]=='+';
            Mapita[i][j-6]='+';
            *ContadorX1=-100;
            return *ContadorX1;
        }
        if(*ContadorX1==-100)
        {
            return *ContadorX1;
        }
    }
    if(Mapita[i][j+4]=='O'&&Mapita[i][j+6]=='O'&&Mapita[i][j+8]=='X')
    {
        if(Mapita[i][j+2]=='+')
        {
            Mapita[i][j+2]=='X';
            Mapita[i][j+4]=='+';
            Mapita[i][j+6]='+';
            *ContadorX1=-100;
            return *ContadorX1;
        }
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i][j-2]=='X')
    {
        Mapita[i][j-2]='Z';
        CtRecursiva_Enemigo(Mapita, i, j-2, Puntos2, ContadorX1, ContadorX2, Contador);
        Mapita[i][j-2]='X';
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i][j-2]=='O')
    {
        Mapita[i][j-2]='Z';
        CtRecursiva_Enemigo(Mapita, i, j-2, Puntos2, ContadorX1, ContadorX2, Contador);
        Mapita[i][j-2]='O';
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i][j-2]=='+')
    {
        Mapita[i][j-2]='X';
        *ContadorX1=-100;
        return *ContadorX1;
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i][j+2]=='O')
    {
        Mapita[i][j+2]='Z';
        CtRecursiva_Enemigo(Mapita, i, j+2, Puntos2, ContadorX1, ContadorX2, Contador);
        Mapita[i][j+2]='O';
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i][j-2]=='X')
    {
        Mapita[i][j-2]='Z';
        CtRecursiva_Enemigo(Mapita, i, j-2, Puntos2, ContadorX1, ContadorX2, Contador);
        Mapita[i][j-2]='X';
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i][j+2]=='+')
    {
        Mapita[i][j+2]='X';
        *ContadorX1=-100;
        return *ContadorX1;
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    //Movimiento Vertical
    if(Mapita[i+2][j]=='O'&&Mapita[i+3][j]=='O'&&Mapita[i+4][j]=='X')
    {
        if(Mapita[i+1][j]=='+')
        {
            Mapita[i+1][j]=='X';
            *ContadorX2=*ContadorX2+1;
            Mapita[i+2][j]='+';
            Mapita[i+3][j]='+';
            *ContadorX1=-100;
            return *ContadorX1;
        }
    }
    if(Mapita[i-2][j]=='O'&&Mapita[i-3][j]=='O'&&Mapita[i-4][j]=='X')
    {
        if(Mapita[i-1][j]=='+')
        {
            Mapita[i-1][j]=='X';
            *ContadorX2=*ContadorX2+1;
            Mapita[i-2][j]='+';
            Mapita[i-3][j]='+';
            *ContadorX1=-100;
            return *ContadorX1;
        }
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i+1][j]=='X')
    {
        Mapita[i+1][j]='Z';
        CtRecursiva_Enemigo(Mapita, i+1, j, Puntos2, ContadorX1, ContadorX2, Contador);
        Mapita[i+1][j]='X';
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i+1][j]=='O')
    {
        Mapita[i+1][j]='Z';
        CtRecursiva_Enemigo(Mapita, i+1, j, Puntos2, ContadorX1, ContadorX2, Contador);
        Mapita[i+1][j]='O';
    }
    
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i+1][j]=='+')
    {
        Mapita[i+1][j]='X';
        *ContadorX1=-100;
        return *ContadorX1;
    }
    if(Mapita[i-1][j]=='O')
    {
        Mapita[i-1][j]='Z';
        CtRecursiva_Enemigo(Mapita, i-1, j, Puntos2, ContadorX1, ContadorX2, Contador);
        Mapita[i-1][j]='O';
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i-1][j]=='+')
    {
        Mapita[i-1][j]='X';
        *ContadorX1=-100;
        return *ContadorX1;
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    //Movimiento Diagonal Horizontal
    if(Mapita[i+2][j+4]=='O'&&Mapita[i+3][j+6]=='O'&&Mapita[i+6][j+8]=='X')
    {
        if(Mapita[i+1][j+2]=='+')
        {
            Mapita[i-1][j-2]=='X';
            *ContadorX2=*ContadorX2+1;
            Mapita[i+1][j+2]='+';
            Mapita[i][j]='+';
            *ContadorX1=-100;
            return *ContadorX1;
        }
        
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i-2][j-4]=='O'&&Mapita[i-3][j-6]=='O'&&Mapita[i-4][j-8]=='X')
    {
        if(Mapita[i-1][j-2]=='+')
        {
            Mapita[i-1][j-2]=='X';
            *ContadorX2=*ContadorX2+1;
            Mapita[i-2][j-4]='+';
            Mapita[i-3][j-6]='+';
            *ContadorX1=-100;
            return *ContadorX1;
        }
        
    }
    if(Mapita[i+1][j+2]=='O')
    {
        Mapita[i+1][j+2]='Z';
        CtRecursiva_Enemigo(Mapita, i+1, j+2, Puntos2, ContadorX1, ContadorX2, Contador);
        Mapita[i+1][j+2]='O';
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i+1][j+2]=='X')
    {
        Mapita[i+1][j+2]='Z';
        CtRecursiva_Enemigo(Mapita, i+1, j+2, Puntos2, ContadorX1, ContadorX2, Contador);
        Mapita[i+1][j+2]='X';
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i+1][j+2]=='+')
    {
        Mapita[i+1][j+2]='X';
        *ContadorX1=-100;
        return *ContadorX1;
    }
    if(Mapita[i-1][j-2]=='O')
    {
        Mapita[i-1][j-2]='Z';
        CtRecursiva_Enemigo(Mapita, i-1, j-2, Puntos2, ContadorX1, ContadorX2, Contador);
        Mapita[i-1][j-2]='O';
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i-1][j-2]=='X')
    {
        Mapita[i-1][j-2]='Z';
        CtRecursiva_Enemigo(Mapita, i-1, j-2, Puntos2, ContadorX1, ContadorX2, Contador);
        Mapita[i-1][j-2]='X';
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i-1][j-2]=='+')
    {
        Mapita[i-1][j-2]='X';
        *ContadorX1=-100;
        return *ContadorX1;
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    //Movimiento vertical Diagonal
    if(Mapita[i+2][j-4]=='O'&&Mapita[i+3][j-6]=='O'&&Mapita[i+4][j-8]=='X')
    {
        if(Mapita[i+1][j-2]=='+')//Comer
        {
            Mapita[i+1][j-2]=='X';
            Mapita[i+2][j-4]='+';
            Mapita[i+3][j-6]='+';
            *ContadorX1=-100;
            return *ContadorX1;
        }
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i-2][j+4]=='O'&&Mapita[i-3][j+6]=='O'&&Mapita[i-4][j+8]=='X')
    {
        if(Mapita[i-1][j+2]=='+')//Comer
        {
            Mapita[i-1][j+2]=='X';
            Mapita[i-2][j+4]='+';
            Mapita[i-3][j+6]='+';
            *ContadorX1=-100;
            return *ContadorX1;
        }
    }
    if(Mapita[i+1][j-2]=='O')
    {
        Mapita[i+1][j-2]='Z';
        CtRecursiva_Enemigo(Mapita, i+1, j-2, Puntos2, ContadorX1, ContadorX2, Contador);
        Mapita[i+1][j-2]='O';
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i+1][j-2]=='X')
    {
        Mapita[i+1][j-2]='Z';
        CtRecursiva_Enemigo(Mapita, i+1, j-2, Puntos2, ContadorX1, ContadorX2, Contador);
        Mapita[i+1][j-2]='X';
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i+1][j-2]=='+')
    {
        Mapita[i+1][j-2]='X';
        *ContadorX1=-100;
        return *ContadorX1;
    }
    if(Mapita[i-1][j+2]=='O')
    {
        Mapita[i-1][j+2]='Z';
        CtRecursiva_Enemigo(Mapita, i-1, j+2, Puntos2, ContadorX1, ContadorX2, Contador);
        Mapita[i-1][j+2]='O';
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i-1][j+2]=='X')
    {
        Mapita[i-1][j+2]='Z';
        CtRecursiva_Enemigo(Mapita, i-1, j+2, Puntos2, ContadorX1, ContadorX2, Contador);
        Mapita[i-1][j+2]='X';
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i-1][j+2]=='O')
    {
        Mapita[i-1][j+2]='Z';
        CtRecursiva_Enemigo(Mapita, i-1, j+2, Puntos2, ContadorX1, ContadorX2, Contador);
        Mapita[i-1][j+2]='O';
        
    }
    if(*ContadorX1==-100)
    {
        return *ContadorX1;
    }
    if(Mapita[i-1][j+2]=='+')
    {
        Mapita[i-1][j+2]='X';
        *ContadorX1=-100;
        return *ContadorX1;
    }
}
void CtCalamardo()
{
  printf("PERDISTE!!!\n");
  printf("        .--'''''''''--. \n");
  printf("     .'      .---.      '.\n");
  printf("   /    .-----------.    |\n");
  printf("  /        .-----.        | \n");
  printf("  |       .-.   .-.       | \n");
  printf("  |     /    | /   |      | \n");
  printf("  |    | .-. | .-. |     / \n");
  printf("   '-._| | | | | | |_.-'\n");
  printf("       | '-' | '-' |\n");
  printf("        |___/ |___/\n");
  printf("     _.-'  /   |  `-._\n");
  printf("   .' _.--|     |--._ '.\n");
  printf("   ' _...-|     |-..._ '\n");
  printf("          |     |\n");
  printf("          '.___.'\n");
  printf("            | |\n");
  printf("           _| |_\n");
  printf("          /|( )/|\n");
  printf("         /  ` '  |\n");
  printf("        | |     | |\n");
  printf("        '-'     '-'\n");
  printf("        | |     | |\n");
  printf("        | |     | |\n");
  printf("        | |-----| |\n");
  printf("     .`/  |     | |/`.\n");
  printf("     |    |     |    |\n");
  printf("     '._.'| .-. |'._.'\n");
  printf("          | | /\n");
  printf("          | | |\n");
  printf("          | | |\n");
  printf("          | | |\n");
  printf("         /| | ||\n");
  printf("       .'_| | |_`.\n");
  printf("       `. | | | .'\n");
  printf("      /  |  |   \n");
  printf("    /o`.-'  / |  `-.`o|\n");
  printf("   /o  o| .'   `. /o  o|\n");
  printf("   `.___.'       `.___.'\n");  
} 


