#include <stdio.h>
#include <stdio_ext.h>
int main()
{
  int puntos1, puntos2, contador;
  char Mapita[22][43];
  int i, j;
  FILE *Archivo;
  Archivo= fopen("juego.bin", "rb");
  fread(&puntos1, sizeof(int), 1, Archivo);
  fread(&puntos2, sizeof(int), 1, Archivo);
  fread(&contador, sizeof(int), 1, Archivo);
  for(i=0; i<22; i++)
    {
      for(j=0; j<43; j++)
	{
	  fread(&Mapita[i][j], sizeof(char), 1, Archivo);
	}
    }
  fclose(Archivo);
  printf("Puntos del jugador 1 %d\n", puntos1);
  printf("Puntos del jugador 2 %d\n", puntos2);
  printf("Contador %d\n", contador);
  for(i=0; i<22; i++)
    {
      for(j=0; j<43; j++)
	{
	  printf("%c", Mapita[i][j]);
	}
      printf("\n");
    }
}
