#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <ctype.h>
#include <stdio_ext.h>
#include "2_Jugadores_Batalla.h"
#include "2_Jugadores_Torneo.h"
#include "1_Jugador_Batalla.h"
#include "1_Jugador_Torneo.h"
struct Def_Leaderboards
{
  char Nombre[30];
  int Puntos;
};
typedef struct Def_Leaderboards LEADERBOARD;
void Bob();
void Leaderboards(LEADERBOARD Ganadores[10]);
void Instructivo();
void Modo(int *modo);
char Opcion(char opc[]);
void Menu(int *opcion);
void Creditos();
int main(int argc, char *argv[])
{
  char opc[10], cont;
  int opcion,  modo;
  LEADERBOARD Ganadores[10];
  if(argc==1)
    {
      printf("Uso: ./Pente -c para creditos, ./Pente -j para jugar, ./Pente -i para instructivo o ./Pente -l para ver leaderboards\n");
      return 0;
    }
  if(argc>2)
    {
      printf("Error: formato incorrecto\n");
      printf("Uso: ./Pente -c para creditos, ./Pente -j para jugar o ./Pente -i para instructivo\n");
      return 0;
    }
  sscanf(argv[1], "%c%c", &opc[0], &opc[1]);
  __fpurge(stdin);
  opc[2]=0;
  switch(Opcion(opc))
    {
    case 'i':
      Instructivo();
      return 0;
      break;
    case 'c':
      Creditos();
      return 0;
      break;
    case 'j':
      Bob();
      Menu(&opcion);
      break;
    case 'l':
      Leaderboards(Ganadores);
      return 0;
      break;
    default:
      printf("Error: opcion invalida\n");
      return 0;
      break;
    }
  system("clear");
  if(opcion==1)
    {
      Modo(&modo);
      if(modo==1)
	{
	  system("clear");
	   printf("\t\t\t\t    Pente\n\n");
	  printf("Bienvenido a modo batalla!\n");
	  printf("Presiona enter para comenzar... ");
	  getchar();
	  __fpurge(stdin);
	  system("clear");
	  PvP_Batalla();
	}
      if(modo==2)
	{
	  system("clear");
	   printf("\t\t\t\t    Pente\n\n");
	  printf("Bienvenido a modo torneo!\n");
	  printf("Presiona enter para comenzar... ");
	  getchar();
	  __fpurge(stdin);
	  system("clear");
	  PvP_Torneo();
	}
    }
  if(opcion==2)
    {
      Modo(&modo);
      if(modo==1)
	{
	  system("clear");
	  printf("\t\t\t\t    Pente\n\n");
	  printf("Bienvenido a  modo batalla!\n");
	  PvE_Batalla();
	}
      if(modo==2)
	{
	  system("clear");
	  printf("\t\t\t\t    Pente\n\n");
	  printf("Bienvenido a modo torneo!\n");
	  PvE_Torneo();
	}
    }
}
char Opcion(char opc[])
{
  if(strcmp(opc, "-c")==0)
    {
      return 'c';
    }
  if(strcmp(opc, "-j")==0)
    {
      return 'j';
    }
  if(strcmp(opc, "-l")==0)
    {
      return 'l';
    }
  if(strcmp(opc, "-i")==0)
    {
      return 'i';
    }
  return '0';
}
void Menu(int *opcion)
{
  float opc;
  char cont;
  system("clear");
   printf("\t\t\t\t    Pente\n\n");
  printf("Bienvenido a Pente!\n");
  printf("Este juego fue creado por Mauricio de Garay Hernandez, Bernardo Garcia Ramos y Daniela Gomez Peniche.\n");
  printf("\n Presiona enter para continuar..... ");
  getchar();
  system("clear");
  do
    {
       printf("\t\t\t\t    Pente\n\n");
      printf("Opcion 1.- Juego de dos jugadores\n");
      printf("Opcion 2.- Juego contra computadora\n");
      printf("Elige tu opcion: ");
      if((scanf("%f", &opc)!=1)||(!(opc-1==0 || opc-2==0)))
	{
	  __fpurge(stdin);
	  printf("ERROR: Dame opciones validas\n");
	  printf("Presiona enter para continuar....");
	  getchar();
	  system("clear");
	}
    }
  while(!(opc-1==0 || opc-2 == 0));
  __fpurge(stdin);
  *opcion=(int)opc;
}
void Instructivo()
{
  system("clear");
  printf("\nReglas del juego:\n");
  printf(" Los jugadores se alternan para colocar piedras en las interseciones libres del tablero. En este caso las\n piedras del jugador uno estan representadas por O y las del jugador dos X, mientras que las intersecciones\n libres estan representadas por un +\n El objetivo del juego es alinear cinco piedras del mismo tipo de forma horizontal, vertical o diagonal. Es\n posible comer fichas del otro jugador y eliminarlas del tablero, si las atrapas entre dos piedras del otro jugador\n solamente se puede comer si hay dos piedras juntas del oponente. No se puede comer si hay menos o mas de\n fichas juntas\nEn el primer turno del jugador uno, no puede poner una ficha a 3 o menos bloques de distancia del centro.\n");
  printf(" Si se come: XOOX ---> X_ _X\n");
  printf(" No se come : XOX ---> X_X\n");
  printf(" Hay tres formas de ganar el juego: Haciendo una fila de 5 fichas, creando 5 filas de 4 fichas o comiendo\n fichas de tu oponente en 5 ocasiones distintas\n\n");
  printf("Puntuacion:\n");
  printf(" Comer al oponente: 10 puntos\n Ganar con una hilera de 5 fichas: 100 puntos\n Ganar por comer 5 veces: 100 puntos\n Ganar por hacer 5 filas de 4 fichas: 100 puntos\n Por cada turno transcurrido el conteo de puntos baja uno, para conseguir mas puntos si terminas antes\n");
}
void Creditos()
{
  system("clear");
   printf("\t\t\t\t    Pente\n\n");
  printf("Desarrolladores:\n");
  printf("Mauricio de Garay Hernandez, Bernardo Garcia Ramos y Daniela Gomez Peniche.\n");
  printf("Materia: Fundamentos de Programacion y laboratorio.\n");
  printf("Maestro Joel Romero Gomez.\n");
  printf("Proyecto Final: Pente.\n");
  printf("Fecha de entrega: 4 de diciembre de 2018.\n");
}
void Leaderboards(LEADERBOARD Ganadores[10])
{
  FILE *Archivo;
  int i=0, totaljug=1;
  if((Archivo= fopen( "leaderboards.txt", "rt"))==NULL)
    {
      printf("ERROR: No existe el archivo 'leaderboards.txt' \n");
    }
  else
    {
      while((fscanf(Archivo, "%s %d\n", Ganadores[i].Nombre, &Ganadores[i].Puntos))==2 || totaljug<10)
	{
	  totaljug=totaljug+1;
	  i=i+1;
	}
      for(i=0; i<totaljug; i++)
	{
	  if(Ganadores[i].Puntos==0)
	    {
	      fclose(Archivo);
	      exit(100);
	    }
	  printf( "%10s %d\n", Ganadores[i].Nombre, Ganadores[i].Puntos);
	}
      fclose(Archivo);
    }
  
}
void Modo(int *modo)
{
  float mode;
  char cont;
  system("clear");
  do
    {
       printf("\t\t\t\t    Pente\n\n");
      printf("Modo 1: Batalla.\nModo 2: Torneo 5 juegos.\n");
      printf("Selecciona tu modo de juego.\n");
      if((scanf("%f", &mode)!=1)||(!(mode-1==0 || mode-2==0)))
	{
	  __fpurge(stdin);
	  printf("ERROR: Dame opciones validas\n");
	  printf("Presiona enter para continuar....");
	  getchar();
	  system("clear");
	}
    }
  while(!(mode==1 || mode == 2));
  *modo= (int)mode;
  __fpurge(stdin);
}
void Bob()
{
  system("clear");
  printf("\n     PROFESOR, LE GUSTA MI TRABAJO FINAL?\n");
  printf("           LO HICE CON MIS LAGRIMAS\n");
  printf("           .--..--..--..--..--..--. \n");
  printf("         .' |  (`._   (_)     _   | \n");
  printf("       .'    |  '._)         (_)  | \n");
  printf("       | _.')|         --..---.   / \n");
  printf("       |(_.'  |    /    .-|-.  |  | \n");
  printf("       |     0|    |--.( O| O).| o| \n");
  printf("        |  _  |  .-|.____.'._.-.  | \n");
  printf("        | (_) | o '.;     -`..-`  | \n");
  printf("         |    |     .--------    / \n");
  printf("         |    |    / |_||_| /    | \n");
  printf("         | o  |    |_______/     | \n");
  printf("         |.-.  |     `-.-'    O  | \n");
  printf("       _.'  .' | .--.--.--.--.  /-._ \n");
  printf("     .'..-.-...'""''---''--'-''.'',,. `-'. \n");
  printf("  ....''                             ''''.... \n");
  printf("  |          .                   .          | \n");
  printf("  ''''...'.'' |                 | ''.'...'''' \n");
  printf("              /                 / \n");
  printf("              |                 | \n");
  printf("              /                 | \n");
  printf("              /                 / \n");
  printf("              /                 | \n");
  printf("              /..-..-..-..-..-..- \n");
  printf("Presiona enter para comenzar el juego... ");
  getchar();
  system("clear");
}
